import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;

public class Instagram{
public static class User {
    String username;
    private String email;
    private String password;
    private List<Post> posts;
    private List<Comment> comments;
    private List<User> followers;
    private List<User> following;
    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.posts = new ArrayList<>();
        this.comments = new ArrayList<>();
        this.followers = new ArrayList<>();
        this.following = new ArrayList<>();
    }
    public void login(){
    Scanner sc = new Scanner(System.in);
    String un = "";
    String pw = "";
        while (true) {
        try {
        System.out.print("Enter username: ");
        un = sc.nextLine();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        try {
        System.out.print("Enter password: ");
        pw = sc.nextLine();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } 
        if (un.equals(username) && pw.equals(password)){
            System.out.println("Login successful!\n");
            break;}
        else
            System.out.println("Invalid username or password");
        }
    }
    public void editProfile(){
        Scanner sc = new Scanner(System.in);
        String em = "";
        try {
        System.out.print("Enter new email: ");
        em = sc.nextLine();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
        email = em;
        System.out.println("Email edited for: "+this.username+"\n");
    }
    public void createPost(String caption) {
        Post post = new Post(this, caption);
        posts.add(post);
        System.out.println("New Post Created by: "+this.username+"\n");
    }
    public void commentOnPost(Post post, String text) {
        Comment comment = new Comment(this, post, text);
        post.addComment(comment);
        comments.add(comment);
        System.out.println(this.username+" commented on Post: "+post.getPostId()+"\n");
    }
    public void addFollower(User follower) {
        followers.add(follower);
        System.out.println("New follower added to: "+this.username+"\n");
    }
    public void addFollowing(User followingUser) {
        following.add(followingUser);
        System.out.println(this.username+" started following: "+followingUser.username+"\n");
    }
    public List<User> getFollowers() {
        return followers;
    }
    public List<User> getFollowing() {
        return following;
    }
    public List<Post> getPosts() {
        return posts;
    }
    public void showAllPosts(){
        for (Post post : this.getPosts()) {
            System.out.println("Post ID: " + post.getPostId());
            System.out.println("Caption: " + post.getCaption());
            System.out.print("Hashtags: [");
            for (Hashtag hashtag : post.getHashtags()) {
                System.out.print(" #" + hashtag.getName());
            }
            System.out.println("]");
            System.out.print("Comments: [");
            for (Comment comment : post.getComments()) {
                System.out.print(comment.getText() + " ");
            }
            System.out.println("]");
        }
        System.out.println();
    }
    public void saveToFile() {
        String data = "Username: "+username+"\n" + "Password: "+password+"\n" + "Email: "+email+"\n";
            for (Post post : this.getPosts()) {
            data += "Post ID: " + post.getPostId() + "\nCaption: " + post.getCaption() + "\nHashtags: [";
            for (Hashtag hashtag : post.getHashtags()) {
                data += " #" + hashtag.getName();
            }
            data += "]\nComments: [";
            for (Comment comment : post.getComments()) {
                data += comment.getText() + " ";
            }
            data += "]\n";
        }
        data += "\n";
        String filePath = "instagram.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(data);
            System.out.println("Data has been written to the file: " + filePath);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }
}

public static class Post {
    private static int i = 1;
    private int postId = 0;
    private String caption;
    private List<Comment> comments;
    private List<Hashtag> hashtags;
    public Post(User user, String caption) {
        postId=i;
        i++;
        this.user = user;
        this.caption = caption;
        this.comments = new ArrayList<>();
        this.hashtags = new ArrayList<>();
    }
    public int getPostId(){
        return postId;
    }
    public void addComment(Comment comment) {
        comments.add(comment);
        System.out.println("New comment on post: "+this.postId+"\n");
    }
    public void addHashtag(Hashtag hashtag) {
        hashtags.add(hashtag);
        System.out.println("New hashtag added to post: "+this.postId+"\n");
    }
    public String getCaption() {
        return caption;
    }
    public List<Hashtag> getHashtags() {
        return hashtags;
    }
    public List<Comment> getComments() {
        return comments;
    }
}

public static class Comment {
    private String text;
    public Comment(User user, Post post, String text) {
        this.user = user;
        this.post = post;
        this.text = text;
    }
    public String getText() {
        return text;
    }
}

public static class Follow {
    private User follower;
    private User following;
    public Follow(User follower, User following) {
        this.follower = follower;
        this.following = following;
    }
    public void follow() {
        follower.addFollowing(following);
        following.addFollower(follower);
    }
    public void unfollow() {
        follower.getFollowing().remove(following);
        following.getFollowers().remove(follower);
        System.out.println("A follower removed for: "+follower.username+"\n");
    }
}

public static class Hashtag {
    private String name;
    private List<Post> posts;

    public Hashtag(String name) {
        this.name = name;
        this.posts = new ArrayList<>();
    }
    public void searchByHashtag() {
        System.out.println("Showing all Posts with #" + name + ":");
        for (Post post : posts) {
            System.out.println("Post ID: " + post.getPostId());
            System.out.println("Caption: " + post.getCaption()+"\n");
        }
    }
    public void addPost(Post post) {
        posts.add(post);
        post.addHashtag(this);
    }
    public String getName() {
        return name;
    }
}    
public static void main(String[] args) {
    Instagram instagram = new Instagram();
    User user1 = new User("tahoor", "tahoor@example.com", "123456");
    User user2 = new User("asma", "asma@example.com", "456789");
    user1.login();
    user1.editProfile();
    user1.createPost("This is my Java post!");
    user1.createPost("This is my C++ post!");
    user1.getPosts().get(0).addHashtag(new Hashtag("java"));
    user1.commentOnPost(user1.getPosts().get(0), "-Great post!");
    user1.commentOnPost(user1.getPosts().get(0), "-Wow!");
    user1.commentOnPost(user1.getPosts().get(0), "-Nice!");
    Follow follow = new Follow(user1, user2);
    follow.follow();
    follow.unfollow();
    Hashtag javaHashtag = new Hashtag("programming");
    javaHashtag.addPost(user1.getPosts().get(0));
    javaHashtag.addPost(user1.getPosts().get(1));
    user1.getPosts().get(1).addHashtag(new Hashtag("C++"));
    user1.commentOnPost(user1.getPosts().get(1), "-Very Useful!");
    user1.commentOnPost(user1.getPosts().get(1), "-Thanks!");
    javaHashtag.searchByHashtag();
    user1.showAllPosts();
    user1.saveToFile();
}
}